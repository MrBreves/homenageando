import Image from "next/image";
import Link from "next/link";
import styles from "./Hero.module.css";

const photos = [
  {
    src: "/images/casal.webp",
    alt: "Casal celebrando uma história de amor",
    className: "couple",
  },
  {
    src: "/images/familia.webp",
    alt: "Família reunida em um momento especial",
    className: "family",
  },
  {
    src: "/images/casamento.webp",
    alt: "Casal celebrando o casamento",
    className: "wedding",
  },
  {
    src: "/images/formatura.webp",
    alt: "Formandos celebrando uma conquista",
    className: "graduation",
  },
];

export default function Hero() {
  return (
    <section className={styles.hero} id="criar">
      {/* CAMADA 1 — fundo artístico independente das polaroides */}
      <div className={styles.backgroundLayer} aria-hidden="true">
        <Image
          src="/images/fundo.webp"
          alt=""
          fill
          priority
          sizes="100vw"
          className={styles.backgroundImage}
        />
        <div className={`${styles.backgroundRegion} ${styles.regionTopLeft}`} />
        <div className={`${styles.backgroundRegion} ${styles.regionTopRight}`} />
        <div className={`${styles.backgroundRegion} ${styles.regionBottomLeft}`} />
        <div className={`${styles.backgroundRegion} ${styles.regionBottomRight}`} />
        <div className={styles.backgroundVignette} />
      </div>

      {/* CAMADA 2 — polaroides reais, sem moldura adicional */}
      <div className={styles.photoLayer} aria-hidden="true">
        {photos.map((photo) => (
          <div
            className={`${styles.photo} ${styles[photo.className]}`}
            key={photo.src}
          >
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              sizes="(max-width: 700px) 18vw, (max-width: 1100px) 180px, 225px"
              className={styles.photoImage}
              priority
            />
          </div>
        ))}
      </div>

      {/* CAMADA 3 — conteúdo central */}
      <div className={styles.heroContent}>
        <span className={styles.eyebrow}>MÚSICAS PERSONALIZADAS</span>

        <h1>
          Transforme seus sentimentos em uma{" "}
          <span>homenagem única.</span>
        </h1>

        <p className={styles.description}>
          Crie sua música personalizada para homenagear alguém especial e
          transformar sua história em uma lembrança inesquecível.
        </p>

        <Link href="/criar" className={styles.cta}>
          Criar minha homenagem <span aria-hidden="true">→</span>
        </Link>

        <span className={styles.note}>
          Você ouvirá um preview de 35 segundos antes de comprar.
        </span>
      </div>
    </section>
  );
}
